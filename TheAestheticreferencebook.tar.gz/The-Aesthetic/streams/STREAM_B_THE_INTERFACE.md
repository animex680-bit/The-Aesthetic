# Stream B — THE INTERFACE
## Digital Product / Tech / AI / Spatial

> "The interface is the product. Make it feel like the future remembered."

---

## 1. Identity

THE INTERFACE is the body stream — the architecture that holds ideas. It draws from premium SaaS product design, spatial computing, AI/ML visual language, generative art, and the best-in-class digital products: Linear, Raycast, Pitch, Apple Vision Pro, Figma.

The reference images that define this stream:
- **Festina One Page Award** — minimalist portfolio (Linear, Pitch, Raycast, Spline, Wander) — pure white space, elegant type, portfolio-grade restraint
- **Liquid Glass UI Kit** — frosted glass components, Nitestudio, modern glass morphism with color substrate visible through
- **Neumorphic design system** — `#EFF2F9` family, Campton + Avenir Next, soft directional shadows
- **Apple Vision Pro profile UI** — spatial UI in mixed reality, depth layers, translucent panels
- **FrsionOS / IRIS_AI** — premium AI product hero sections: "WHERE AI MERGES with // YOUR VISION"
- **Observatory app** — dark mode wellness AI: "Reality Checks", "Your Aura", "You're a badass!" — emotional precision
- **Nike + AI concept "DESTINY"** — dark AI-powered athletic interface, bold typography over dark textures
- **Generative art prompt**: "emerge from code, 3D holographic projections made by tiny white dots, minimalism, pure black background" — particle field aesthetic
- **Cosmos hero section** — scroll-depth UI, cosmic palette
- **Music app UI** — Ariana Grande, dark themed, album art dominant

**The feeling**: You are looking at something that was designed. Not decorated — designed. Every element is where it is for a reason. The product communicates intelligence before you use it.

---

## 2. Color System

### Dark Mode (Primary — always default for Stream B)
```json
{
  "bg_void":        { "hex": "#0C0C10", "use": "Base background — near-black with blue undertone" },
  "surface_l1":     { "hex": "#141418", "use": "Card, panel background" },
  "surface_l2":     { "hex": "#1E1E26", "use": "Elevated panel, modal base" },
  "surface_l3":     { "hex": "#28282F", "use": "Tooltip, overlay, dropdown" },
  "border_subtle":  { "hex": "#2A2A35", "use": "Dividers, card borders" },
  "border_medium":  { "hex": "#3A3A48", "use": "Active borders, focus rings" },
  "text_primary":   { "hex": "#F0F0F6", "use": "Headlines, primary text" },
  "text_secondary": { "hex": "#9090A8", "use": "Subtitles, descriptions" },
  "text_muted":     { "hex": "#5C5C72", "use": "Placeholders, captions" }
}
```

### Light Mode (Neumorphic)
*Taken directly from reference "Virtual assistant app in neomorphic design" — exact spec*
```json
{
  "bg_light":       { "hex": "#EFF2F9", "use": "Background — soft grey-blue" },
  "surface_light":  { "hex": "#E4EBF1", "use": "Card, panel — slightly darker than bg" },
  "muted_light":    { "hex": "#B5BFC6", "use": "Borders, muted text" },
  "text_light":     { "hex": "#6E7F8D", "use": "Primary text in light mode" },
  "shadow_inner_l": { "hex": "#FAFBFF", "use": "Inner shadow — light side", "opacity": 1.0 },
  "shadow_inner_d": { "hex": "#161B1D", "use": "Inner shadow — dark side", "opacity": 0.23 }
}
```

### Glass System
```json
{
  "glass_fill":     { "rgba": "rgba(255,255,255,0.06)", "use": "Frosted glass panel fill" },
  "glass_fill_med": { "rgba": "rgba(255,255,255,0.10)", "use": "Elevated glass element" },
  "glass_border":   { "rgba": "rgba(255,255,255,0.12)", "use": "Glass edge highlight" },
  "glass_border_str":{ "rgba": "rgba(255,255,255,0.20)", "use": "Active glass border" },
  "glass_backdrop": { "value": "blur(20px) saturate(1.8)", "use": "Backdrop filter on glass elements" }
}
```

### Accent Colors
```json
{
  "accent_blue":    { "hex": "#3B82F6", "use": "Primary interactive, links, CTA" },
  "accent_teal":    { "hex": "#0EA5E9", "use": "AI, data, intelligence, real-time" },
  "accent_purple":  { "hex": "#8B5CF6", "use": "Generative, creative, AI-imaginative" },
  "accent_emerald": { "hex": "#10B981", "use": "Success, positive states" },
  "accent_amber":   { "hex": "#F59E0B", "use": "Warning, attention, premium gold" },
  "accent_rose":    { "hex": "#F43F5E", "use": "Error, critical, power" }
}
```

### Gradient Recipes
```css
/* Hero gradient — deep space */
background: radial-gradient(ellipse 80% 50% at 50% 0%, rgba(59,130,246,0.15) 0%, transparent 70%),
            radial-gradient(ellipse 60% 40% at 80% 100%, rgba(139,92,246,0.10) 0%, transparent 70%),
            #0C0C10;

/* Glass tint */
background: linear-gradient(135deg, rgba(255,255,255,0.10), rgba(255,255,255,0.03));

/* Particle field tint */
background: radial-gradient(ellipse 100% 100% at 50% 50%, rgba(14,165,233,0.08) 0%, transparent 100%), #0C0C10;
```

---

## 3. Typography

### Font Stack
```
DISPLAY (Hero):      SF Pro Display, Geist, Inter Display, Campton
HEADING (UI):        SF Pro Text, Inter, Campton Book
BODY:                SF Pro Text, Avenir Next, Inter, Campton Light
MONO (code/data):    JetBrains Mono, Fira Code, SF Mono
LABEL (ALL CAPS):    Inter, Campton — tracking 0.1em, weight 500
```

### Exact Neumorphic Spec (from reference)
```
Campton Book    — UI labels, button text
Campton Light   — body, descriptions
Avenir Next Medium — headings, numbers
```

### Type Scale (8pt base)
```
xs:   11px / 1.4 / 400 / tracking: +0.02em
sm:   13px / 1.5 / 400 / tracking: 0
base: 16px / 1.6 / 400 / tracking: 0
lg:   20px / 1.4 / 500 / tracking: -0.01em
xl:   28px / 1.3 / 600 / tracking: -0.02em
2xl:  40px / 1.2 / 700 / tracking: -0.03em
3xl:  56px / 1.1 / 700 / tracking: -0.04em
hero: 80-120px / 1.0 / 700-800 / tracking: -0.04em
```

### Type Rules
- Headlines: tight negative tracking, heavy weight — modern tech precision
- Body: comfortable line height (1.6), never tight
- All-caps labels: +0.1em tracking, weight 500 or 600
- Mono for any number, data, or code
- Never use italic for interface copy (exception: decorative Stream A blend moments)
- Max 2 typefaces in UI contexts. Prefer 1.

---

## 4. Motion Language

### Principles
THE INTERFACE moves like a precision instrument. Fast when responding. Elegant when presenting.

**Micro-interactions** (state changes, hover, press):
- Duration: 150–200ms
- Ease: ease-out or cubic-bezier(0.2, 0, 0, 1)

**Component transitions** (modal open, panel slide, tab change):
- Duration: 250–350ms
- Ease: cubic-bezier(0.32, 0.72, 0, 1) — fast start, gentle finish

**Page / hero transitions** (route change, major reveal):
- Duration: 400–600ms
- Ease: cubic-bezier(0.16, 1, 0.3, 1)

**Atmospheric animations** (glass shimmer, particle field, ambient):
- Duration: 2000–6000ms loop
- Ease: ease-in-out or linear

### Approved Moves (Stream B)
1. **Fade + scale** `opacity:0→1, scale:0.96→1.0` — 250ms — standard element entry
2. **Slide up** `translateY:16px→0, opacity:0→1` — 300ms — content section reveal
3. **Glass shimmer** slow specular highlight sweep — 3000ms loop
4. **Particle field** dots materializing from void, velocity-based fade — 60fps
5. **Staggered list** each item delayed by 40ms from previous
6. **Skeleton → content** placeholder pulse, then content snap-in at 200ms
7. **Counter animation** number rolling from 0 to value, 800ms ease-out
8. **Typing cursor** text appearing as if typed — 20ms per character
9. **Data viz reveal** bars/lines drawing in from 0%, ease-out, staggered

### Spring Physics Spec (for UI components)
```
Standard spring:  stiffness: 200, damping: 20, mass: 1
Snappy spring:    stiffness: 400, damping: 30, mass: 1
Gentle spring:    stiffness: 100, damping: 15, mass: 1
```

---

## 5. Component Patterns

### Glass Card
```css
background: rgba(255, 255, 255, 0.06);
border: 1px solid rgba(255, 255, 255, 0.12);
border-radius: 16px;
backdrop-filter: blur(20px) saturate(1.8);
box-shadow: 0 4px 32px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255,255,255,0.1);
```

### Neumorphic Card (Light Mode)
*From exact reference spec:*
```css
background: #E4EBF1;
border-radius: 16px;
/* Shadow 1 (light) */  box-shadow: -5px -5px 10px #FAFBFF;
/* Shadow 2 (dark) */   box-shadow: 5px 5px 10px rgba(22, 27, 29, 0.23);
/* Combined: */
box-shadow: -5px -5px 10px #FAFBFF, 5px 5px 10px rgba(22, 27, 29, 0.23);

/* Deep (20px offset, 40px blur): */
box-shadow: -20px -20px 40px #FAFBFF, 20px 20px 40px rgba(22, 27, 29, 0.23);
```

### Button (Primary)
```css
background: #3B82F6;
color: #FFFFFF;
border-radius: 8px;
padding: 10px 20px;
font: 500 14px/1 Campton, Inter, sans-serif;
letter-spacing: 0.01em;
transition: all 150ms ease-out;
/* hover: */ filter: brightness(1.1);
/* press: */ scale: 0.97;
```

### Button (Secondary / Glass)
```css
background: rgba(255,255,255,0.08);
border: 1px solid rgba(255,255,255,0.15);
color: #F0F0F6;
border-radius: 8px;
backdrop-filter: blur(8px);
padding: 10px 20px;
transition: all 150ms ease-out;
/* hover: */ background: rgba(255,255,255,0.12);
```

---

## 6. Generative Art Direction

From reference: *"generative art, emerge from code, 3D holographic projections made by tiny white dots, minimalism, pure black background"*

### Particle Field Spec
```
Background: pure #000000 or #0C0C10
Particle color: #FFFFFF, opacity: 0.4–0.8 (randomized)
Particle size: 1–2px, crisp (no blur on individual particles)
Field density: 2000–6000 particles per 1920×1080
Motion: very slow drift (0.1–0.5 px/frame), slight rotation
Depth: z-axis simulation via size variation (near: 2px, far: 0.5px)
Color variant: replace white with accent_teal at 30% mix
```

### Holographic Material (3D)
```
Base color: any solid hue
Specular: very high (0.9+)
Metallic: 0.7–1.0
Roughness: 0–0.15
Environment: HDRI with high contrast (interior or studio)
Color variation: iridescent shift as camera/light changes angle
```

---

## 7. Reference Images (Drive)

From "my aesthetics2" folder:

### Portfolio / Web
- `Festina - One Page Website Award.jpg` — Festina investment fund. Linear, Pitch, Raycast portfolio. **The gold standard for minimalist portfolio web.**
- `hero section ux _ Cosmos.jpg` — Cosmos hero section — dark, typographic, scroll depth
- `💻High-end websites for founders, experts….jpg` — IRIS_AI: "WHERE AI MERGES with // YOUR VISION"

### UI / Design Systems
- `Virtual assistant app in the neomorphic design….jpg` — **EXACT SPEC SOURCE**: colors `#EFF2F9, #E4EBF1, #B5BFC6, #6E7F8D`, Campton + Avenir Next, shadow spec
- `Read the full liquid glass guide to define….jpg` — Liquid Glass UI Kit: Primary/Secondary buttons, toast, tabs, search
- `Sleek liquid glass effect meets bold colors and….jpg` — Glass over saturated color substrate
- `UI_UX Savior on X_ Same glass, different….jpg` — Glass variation studies

### Spatial / Future UI
- `Threads: Vision Pro. UI Design 💭💖.jpg` — Apple Vision Pro UI, spatial panels, depth layers
- `A premium, emotionally intelligent interface….jpg` + `(1).jpg` + `(2).jpg` — FrsionOS cloud/AI platform
- `8796161770502459.jpg` — Observatory app dark mode: wellness AI, emotional UI language
- `Close-up depiction of a sleek futuristic helmet….jpg` — Midjourney sci-fi cyborg reference

### Typography / Brand
- `#typography.jpg` — Type-forward composition reference
- `Presenting my latest modern UI design concept for….jpg` — Nike AI "DESTINY AND WAY OUT" — dark athletic AI
- `Dive into the sleek world of automotive graphic….jpg` — Porsche UI — precision tech meets luxury product

### Generative Art
- `X.jpg` — The dot-matrix manifesto: "generative art, emerge from code, 3D holographic projections made by tiny white dots, minimalism, pure black background"

---

## 8. Stream B Anti-Patterns

Never do these in Stream B work:

- Gradients with 5+ color stops without generative purpose
- UI elements without a design system (every component must reference the token system)
- Mixing glassmorphism AND neumorphism in the same section without intention
- Rounded corners above 24px for most UI (except modals: max 32px)
- Colored text on colored backgrounds (always check WCAG AA at minimum)
- Particle fields that run below 30fps
- Typography that ignores the scale — do not size by feel, size by system
- Hover states that change color dramatically (subtle shifts only)
- Dark mode implemented as "just change background to #000000"
