# Content & Social — Rules
## Instagram Feed, Reels, Thumbnails, Social Posts

---

## Platform Specs

| Format | Dimensions | Duration | Notes |
|--------|-----------|---------|-------|
| IG Reel | 1080×1920 | 15–90s | Vertical, 24fps or 30fps |
| IG Feed (square) | 1080×1080 | — | Consider carousel series |
| IG Feed (portrait) | 1080×1350 | — | Taller = more feed space |
| IG Story | 1080×1920 | 15s | Interactive elements |
| YouTube Thumbnail | 1280×720 | — | Must read at 150px |
| LinkedIn Post | 1200×628 | — | Horizontal dominant |
| Twitter/X Banner | 1500×500 | — | Centered subject |

**IG Safe Zones (Reels)**:
```
Top:    14% — below story progress bars and avatar
Bottom: 18% — above caption, like, comment controls
Sides:  4%
```

---

## Stream Selection for Social Content

### Instagram Feed (Static)
Primary Stream A — editorial, sculptural, stop-scroll through stillness.

**What works on feed**:
- Dark editorial imagery (mannequin, chrome, texture)
- Single powerful subject — no busy collages
- Minimal text overlay — one word or phrase maximum
- Color: dark/muted, stand out in a sea of bright/natural photos
- Series: 3 or 6-frame carousel with a consistent left-edge visual thread

### Instagram Reels
Blend: A 50% (visual quality) / B 50% (motion graphics structure)

**What works in Reels**:
- Strong first frame (0–1.5s decides if they keep watching)
- Kinetic typography synced to voice or music
- Motion graphics that ADD information without OBSCURING the presenter
- Consistent color grade across the video
- Clear visual hierarchy: subject > supporting graphic > label

---

## Color Grading for Social Video

**Stream A Grade** (editorial, moody):
```
Shadows:    Teal lift (+14 blue, +6 green in shadows)
Midtones:   Slightly desaturated (saturation -10 to -20)
Highlights: Preserve or very slightly warm (+5 red)
Blacks:     Crush (-6 to -10 in lift/pedestal)
Contrast:   +6 to +10
Vignette:   Subtle (opacity 20-30%, large radius)
Result:     Rich, dark, teal-shadow editorial look
```

**Stream B Grade** (clean tech/product):
```
Whites:     Clean, not blown (stay under 95%)
Blacks:     Deep but with blue undertone
Saturation: Normal to slightly boosted (+10)
Contrast:   Moderate (+5)
Temperature:Neutral to slightly cool (shift -3 to -5)
Result:     Clean, precise, premium tech look
```

---

## Typography on Social

### Feed Posts
- If text overlay: ONE message, huge, covering 20–40% of frame
- Font: Stream A = Cormorant italic / Stream B = Inter bold
- Color: Bone white (#F0EFE8) always — never pure white (too harsh)
- No more than 8 words total on a static image

### Reels / Video Text
Follow `/rules/motion-graphics.md` for all overlay specs.

**Caption / Subtitle style** (when used):
```
Font:       Inter Medium or Helvetica Neue Medium
Size:       36–42px
Color:      #FFFFFF with background: rgba(0,0,0,0.5)
Border-radius: 6px on the background pill
Position:   Bottom safe zone, horizontally centered
```

---

## Thumbnail Design

Thumbnails must:
1. Be readable at 150px wide (test this)
2. Have one clear subject (face or key visual)
3. Include 3 words maximum if using text
4. Use high-contrast text (white or yellow on dark, dark on light)
5. Not look like clickbait (our brand = premium and real)

**Thumbnail style**:
- Dark overlay gradient from bottom (opacity 0→0.7)
- Subject occupies top 60% of frame
- Text at bottom 25%, large and clean
- Subtle brand color accent (one color from stream palette)

---

## Content Mood Board Per Platform

### Instagram Feed — "THE GALLERY"
Treat the feed as a gallery. Ask: "Would this look good in a museum?"
- Consistent aspect ratio (portrait: 4:5 = 1080×1350)
- 3-image planning: consider how 3 adjacent posts look together
- No post should look the same as the previous 3
- Dark posts alternate with slightly lighter posts for rhythm
- Editing: consistent grade across all posts

### Instagram Reels — "THE STATEMENT"
Every Reel is a statement, not filler.
- Opening frame: dark, one face or one visual + silence, then motion hits
- Middle: kinetic typography or graphics at peak engagement point (15–30s)
- End: clear verbal/visual CTA, simple, no cluttered graphic

### LinkedIn — "THE BRIEF"
LinkedIn is where precision matters more than emotion.
- Stream B dominant (80%)
- Clean dark or clean light (not dark-only — LinkedIn users see both)
- Infographics with actual data — not decorative "fake stats"
- Typography: Inter or DM Sans — readable at small sizes
- No excessive graphic decoration — the content is the content

---

## Anti-Patterns for Social

**Never do**:
- White background content (we are dark-first always)
- Fonts smaller than 24px in Reels
- Text in the safe-zone danger areas (corners, very top, very bottom)
- More than 3 different text styles in a single frame
- Gradient backgrounds without a subject (generic)
- Cheap sparkle/glow effects without purpose
- Placing graphics over the face of a speaking subject
- Posting anything that looks like it came from a Canva template
- Using the same color as the background for text (obvious — but check)

---

## Production Quality Bar

Before publishing:
- [ ] First frame grabs attention within 0.5 seconds
- [ ] Safe zones respected — nothing critical near edges
- [ ] Audio levels normalized (-14 LUFS for Instagram)
- [ ] Caption added (accessibility + silent viewers = 80% of Reels watched muted)
- [ ] Color grade applied consistently
- [ ] All text legible at export size (export 1080×1920, check at 375px preview)
- [ ] Aspect ratio correct for platform
- [ ] No temporal linear motion — all animations use easing
