# 3D Assets — Rules
## Models, Renders, Illustrations, CGI

---

## Stream Selection for 3D Assets

3D assets lean Stream A: **sculptural, editorial, material-obsessed**.
Stream B informs the technical precision and cleanliness of the geometry.

**Default**: A 70% / B 30%

---

## Material Philosophy

### Stream A Materials (Fine Art)

**Chrome / Reflective Metal**  
*Reference: "Chrome face mask reflecting the world in silence"*
```
Metalness:      0.95–1.0
Roughness:      0.0–0.08
Color:          #B2BFC9 (chrome mid) or #D4DDE2 (bright chrome)
Environment:    High-contrast HDRI (interior, studio, or urban)
Key property:   The reflection IS the subject. Render it clean.
```

**Porcelain / Resin (Mannequin)**  
*Reference: "mannequin face & texture" + "Serene mannequin head"*
```
Metalness:      0.0
Roughness:      0.05–0.15
Color:          #EDE8E0 (bone) or #E8D5C8 (warm skin)
Subsurface:     Subtle SSS (subsurface scattering) at 5–8% for skin warmth
Specular:       Tight highlight (IOR ~1.5)
Light:          Soft box or diffuse area light from above/side
```

**Raw Concrete**
```
Metalness:      0.0
Roughness:      0.65–0.75
Color:          #666870 (mid grey) or #8C8880 (warm grey)
Normal map:     Subtle micro-grain, not heavy texture
Light:          Dramatic side-lighting shows the grain
```

**Matte Dark Surface**
```
Metalness:      0.0–0.05
Roughness:      0.85–0.95
Color:          #0D0D0F to #1A1A1E
Purpose:        Let the subject be the light, not the surface
```

### Stream B Materials (Tech Product)

**Holographic / Iridescent**
```
Metalness:      0.6–0.8
Roughness:      0.0–0.05
Color shift:    Changes with view angle (thin-film interference)
Blender:        ShaderFX with Iridescence or MagicaShader
Environment:    Dark HDRI, enhance the shift
```

**Dark Anodized Aluminum**
```
Metalness:      0.8
Roughness:      0.15–0.20
Color:          #1A1A20 (near-black with blue)
Highlights:     Very tight specular (clean product)
```

**Liquid Glass (3D)**
```
Transmission:   0.85–0.95
IOR:            1.52
Roughness:      0.0
Color:          Slight tint of accent color (blue, teal)
Thickness:      Model actual thickness for realistic refraction
```

---

## Lighting Setups

### Setup 1: Editorial Drama (Stream A)
```
Key light:      Area light, 1.5m × 1.5m, 45° from subject, right side
                Color: warm white #FFF5E8, intensity: 4.0
Fill light:     Opposite side, 0.5× key intensity, very diffuse
                Color: slightly blue #E8F0FF, intensity: 1.0
Rim light:      Behind subject, thin strip light
                Color: white or teal #0EA5E9, intensity: 2.0
Background:     0D0D0F — almost nothing
Mood:           Three-quarter lit, deep shadow on one side
```

### Setup 2: Soft Pastel (Stream A — Mannequin reference)
```
Key light:      Large diffuse softbox, overhead-front
                Color: desaturated rose #C4A89A, intensity: 2.0
Fill:           Large diffuse panel from opposite, 0.7× intensity
                Color: muted lavender #9E97B0
Background:     Very dark: void black or very dark teal
Result:         Soft, dreamy, the subject glows
```

### Setup 3: Product Studio (Stream B)
```
Key light:      Small area light, position product at 45°
                Color: pure white #FFFFFF
Fill:           Opposite large area, 0.3× intensity
Bottom bounce:  Subtle reflector below, 0.1× intensity
Background:     Pure black #000000 or very dark navy
Result:         Clean, commercial, precise
```

### Setup 4: Particle Field (Stream B — Generative)
```
Environment:    None (or very dark radiance-only HDRI)
Background:     Pure black #000000
Subject lit:    By internal emission or very subtle point lights
Particles:      White emissive material, point sprites, 60fps animation
```

---

## Rendering Specifications

### Web-Bound Assets (glTF/glb)
```
Polygon budget:     10k–50k tris per hero asset
                    < 10k tris for background/secondary assets
Textures:           KTX2 (compressed) preferred
                    2048×2048 max (1024 preferred for secondary)
Normal maps:        Yes, baked from high-poly
Metalness/Roughness:Combined map (metalness R, roughness G)
File size:          < 2MB per asset for web
Tools:              Blender → Draco compression → web
```

### High-Resolution Renders (PNG/EXR for compositing)
```
Resolution:     2160×2160 minimum (4K for hero renders)
Color depth:    32-bit EXR for post-processing
Samples:        1000+ Cycles or equivalent in other renderers
Denoising:      AI denoiser at export (Optix or OpenImageDenoise)
DOF:            Shallow depth of field for product isolation
Color space:    ACES or Linear for EXR, sRGB for PNG delivery
```

---

## 3D Composition Rules

- **Negative space**: the 3D object should NOT fill more than 60% of frame
- **Camera angle**: 15–30° elevation, slight 3/4 turn — not flat-on (boring)
- **Depth of field**: focused on the "face" of the object, background soft
- **Environment reflection**: always some reflection visible on specular surfaces
- **Teal shadow**: add a subtle teal color to the shadow fill — prevents dead blacks
- **One hero light**: more lights = flatter, less drama

---

## Illustration Style (if not 3D photography)

Based on the generative art reference and the aesthetic streams:

**Stream A Illustration**:
- Gestural, hand-drawn quality
- Textured brushwork (Procreate, analog brush)
- Limited palette: 3 colors maximum
- Organic forms, not geometric
- High contrast between subject and background

**Stream B Illustration / Generative**:
- Mathematical, precise
- Particle-based or vector
- Clean geometric forms
- Dark background, light elements
- "Emerge from code" aesthetic (tiny dots, lines, fields)
- Motion-ready (can be animated)
- Tools: p5.js, Three.js geometry, Midjourney (for reference), or custom GLSL shaders

---

## Quality Check for 3D Assets

- [ ] Polygon count within budget for intended platform
- [ ] Textures are power-of-two and compressed
- [ ] Normals clean (no flipped faces, no holes)
- [ ] Material setup uses PBR correctly (metalness/roughness, not specular/gloss)
- [ ] Renders pass the "could this appear in a premium brand ad?" test
- [ ] No flat grey environments — always intentional lighting
- [ ] Teal undertone in shadows (both streams)
- [ ] glTF export validated in three.js or model viewer before delivery
