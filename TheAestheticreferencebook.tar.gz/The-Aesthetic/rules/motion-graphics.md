# Motion Graphics — Rules
## For CapCut, After Effects, Remotion, and any motion overlay work

---

## When to Use Motion Graphics

Motion graphics are an *overlay* — they sit on top of video. Their job is to:
1. **Amplify** what the video is already saying
2. **Guide** the viewer's eye to what matters
3. **Punctuate** key moments
4. **Add depth** without competing with the main content

They must NEVER:
- Cover the subject's face or lips during speech
- Appear at the same time as critical on-screen text in the video
- Compete with the audio for attention
- Feel busy or decorative for its own sake

---

## Stream Selection for Motion Graphics

**Default: 50/50 blend — B controls structure, A controls emotion**

| Video Content Type | Primary Stream | Rationale |
|---|---|---|
| Tech / product / AI content | B 70% | Matches the subject matter |
| Personal brand / editorial | A 60% | Emotional, premium personal feel |
| Finance / business | B 60% | Authority, precision |
| Lifestyle / fashion | A 70% | Editorial energy |
| Music / cultural | A 50% + B 50% | Depends on genre |
| Tutorial / explainer | B 80% | Clarity over style |

---

## Layout Rules (Vertical Video — 1080×1920)

**Safe Zones** (do not place critical elements outside these):
```
Top safe:     y > 14% of height = y > 269px
Bottom safe:  y < 82% of height = y < 1574px
Left safe:    x > 4% of width  = x > 43px
Right safe:   x < 96% of width = x < 1037px
```

**Placement Strategy**:
- Lower third: 75%–85% height (inside safe zone)
- Title card: 15%–40% height
- Kinetic text: center-ish but offset — never perfectly centered
- Decorative elements (lines, sweeps): hug the safe zone edges

---

## Typography in Motion Graphics

**Preferred Fonts**:
- Stream A overlay: Cormorant Garamond, Didot (thin/light weight)
- Stream B overlay: Inter, Geist, SF Pro (medium/bold)
- Hybrid: Inter for structured info, Cormorant for emotional beats

**Size Guidelines**:
- Primary kinetic text: 80–140pt (fills frame intentionally)
- Supporting text: 24–48pt
- Labels/callouts: 16–24pt, ALL CAPS, wide tracking
- Subtitles/captions: 32–42pt, high contrast

**Color on Video**:
- Always high contrast against the underlying footage
- White or Bone (#F0EFE8) with a subtle text shadow for legibility
- Never use color-only contrast (always have luminance contrast too)
- Text shadow: `0 2px 8px rgba(0,0,0,0.6)` minimum on complex backgrounds

---

## Approved Motion Graphics Moves

### Lower Thirds
```
Entry:  Slide from left + fade, 300ms ease-out (Stream B)
        OR: Fade in from 0 over 800ms (Stream A)
Hold:   Static, no movement
Exit:   Fade to 0, 400ms ease-in
        OR: Slide out right, 300ms
Timing: Appears 0.5s after cut, disappears 0.5s before next cut
```

### Title Cards (Full Screen)
```
Entry:  Black/dark frame → fade-in background, then text clip-reveal
        Duration: 1200ms (A) or 600ms (B)
Hold:   3–5 seconds minimum for readability
Exit:   Fade to black or cut
```

### Kinetic Typography
```
Entry method:  Scale punch (scale 0.92→1.18→1.0), or clip reveal
Timing:        Sync to audio beat or speech start
Color:         White default; gradient (teal→purple→orange) for emphasis words
Hold:          Word/phrase holds for its full duration in audio
Exit:          Fade or scale down to 0.95 + fade, quick (200ms)
Peak scale:    1.15–1.18 MAX — never 1.30+
```

### Call-to-Action (CTA) Text
```
Entry:  Slide up + fade, 400ms
Style:  ALL CAPS, wide tracking, Stream B colors
Background: Semi-transparent glass panel (rgba(0,0,0,0.5)) or gradient bar
```

### Sweep Lines / Decorative Elements
```
Lines: Constrain to safe margins ALWAYS
       sl = screen_left + 4% margin
       sr = screen_right - 4% margin
       Span only within these bounds
Opacity: 0.2–0.4 (subtle, not distracting)
Color: White or the video's dominant accent color
Animation: Draw from 0% to 100% over 400–600ms
```

### Corner Brackets
```
Position: Anchored to safe area corners (not screen corners)
  Top-left:     (4% + 12px, 14% + 12px)
  Top-right:    (96% - 12px, 14% + 12px)
  Bottom-left:  (4% + 12px, 82% - 12px)
  Bottom-right: (96% - 12px, 82% - 12px)
Size: 40–60px per arm
Animation: Draw in from corner point, 300ms each arm (staggered)
```

---

## Pacing Rules

- **Never monotonous**: vary the type of motion graphic every 3–5 seconds
- **Never constant**: allow at least 1–2 seconds of bare video between overlays
- **Sync to audio**: text entries should align with speech starts or beats
- **No random cuts**: every graphic appears for a reason tied to content
- **Breathing room**: after a kinetic typography moment, let the video breathe for 1.5s+

---

## Color on Video (Overlay)

**Default**: White / Bone on dark video. Dark on light video.

**Accent use**:
- Stream B accents (blue, teal, purple) for tech/product content
- Stream A accents (rose, chrome, gold) for editorial/lifestyle

**Glass overlay panels**:
```
background: rgba(0, 0, 0, 0.5)
backdrop-filter: blur(12px)
border: 1px solid rgba(255,255,255,0.15)
border-radius: 12px
```

---

## Sound and Visual Synchronization

- Hard cut graphics sync to downbeat or sharp transient
- Soft fade graphics sync to phrase boundaries
- Kinetic type: each word/phrase enters on its natural speech emphasis
- If no music, let the speech pacing dictate all timings
- Silence in the audio = possible moment for a graphic to quietly appear or disappear

---

## Quality Check Before Delivery

- [ ] No critical content is hidden under graphics
- [ ] All text is within safe zones
- [ ] Corner brackets and sweep lines do NOT cross safe zone boundaries
- [ ] Peak scale on kinetic text ≤ 1.18 (never exceeds safe area)
- [ ] Minimum 1 second between overlapping graphic events
- [ ] Every graphic has a purpose tied to the content
- [ ] High contrast text is legible on the actual video footage (not just on black)
- [ ] No linear easing anywhere
