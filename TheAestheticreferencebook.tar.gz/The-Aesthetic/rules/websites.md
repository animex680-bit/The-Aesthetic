# Websites — Rules
## Web Design & 3D Web Experiences (Vite, Three.js, R3F, GSAP)

---

## Stream Selection for Websites

| Project Type | Primary | Secondary |
|---|---|---|
| Agency / creative studio | A 50% | B 50% |
| SaaS product site | B 70% | A 30% |
| Personal brand | A 60% | B 40% |
| 3D immersive WebGL | A texture + B structure | — |
| Portfolio | B 60% | A 40% |
| E-commerce (premium) | A 50% | B 50% |
| AI/tech product | B 80% | A 20% |

---

## Layout & Grid

**Base unit**: 8px  
**Max content width**: 1200px (centered)  
**Gutters**: 24px mobile, 32px tablet, 48px desktop  
**Columns**: 4 (mobile), 8 (tablet), 12 (desktop)

**Hero section**:
- Minimum: 90vh (not 100vh — allow scroll hint)
- Background: deep dark (#0C0C10) with radial gradient accents
- No sliders/carousels in heroes — one statement, maximum impact

**Section spacing**: 120px–180px between sections (breathe)

---

## Navigation

- **Height**: 64px desktop, 56px mobile
- **Background**: transparent on hero, `rgba(12,12,16,0.8)` + blur on scroll
- **Logo**: left-aligned
- **Nav links**: right-aligned, 14px Inter 500, tracking +0.02em, muted color → white on hover
- **CTA button**: extreme right, solid or glass style
- **Mobile**: hamburger → full-screen dark overlay menu, not sidebar

---

## Typography on Web

Follow `/tokens/typography.json` — Stream B defaults for all web.

```css
/* HTML base */
html { font-size: 16px; }

/* Heading scale */
.h-hero  { font-size: clamp(56px, 8vw, 96px); font-weight: 700; letter-spacing: -0.04em; }
.h1      { font-size: clamp(40px, 5vw, 64px);  font-weight: 700; letter-spacing: -0.03em; }
.h2      { font-size: clamp(28px, 4vw, 48px);  font-weight: 600; letter-spacing: -0.02em; }
.h3      { font-size: clamp(20px, 3vw, 32px);  font-weight: 600; letter-spacing: -0.01em; }
.body    { font-size: 16px; font-weight: 400; line-height: 1.6; letter-spacing: 0; }
.label   { font-size: 11px; font-weight: 500; letter-spacing: 0.1em; text-transform: uppercase; }
```

**For Stream A moments within B-primary sites**:
```css
.editorial-title { font-family: 'Cormorant Garamond', serif; font-weight: 300; letter-spacing: 0.08em; }
```

---

## Color on Web

**Dark mode is default**. Light mode is opt-in per project.

```css
:root {
  --bg:            #0C0C10;
  --surface:       #141418;
  --surface-2:     #1E1E26;
  --border:        #2A2A35;
  --text:          #F0F0F6;
  --text-2:        #9090A8;
  --text-3:        #5C5C72;
  --accent:        #3B82F6;
  --accent-2:      #0EA5E9;
  --glass:         rgba(255,255,255,0.06);
  --glass-border:  rgba(255,255,255,0.12);
}
```

---

## Glassmorphism

Reference: "Liquid Glass UI Kit" + "Sleek liquid glass effect" reference images.

```css
.glass-card {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  backdrop-filter: blur(20px) saturate(1.8);
  box-shadow: 0 4px 32px rgba(0, 0, 0, 0.4),
              inset 0 1px 0 rgba(255, 255, 255, 0.10);
}

/* On hover */
.glass-card:hover {
  background: rgba(255, 255, 255, 0.09);
  border-color: rgba(255, 255, 255, 0.18);
  transition: all 200ms cubic-bezier(0.2, 0, 0, 1);
}
```

---

## Scroll Animations (GSAP + ScrollTrigger)

```javascript
// Standard section reveal
gsap.fromTo('.section-element', 
  { opacity: 0, y: 40 },
  { 
    opacity: 1, y: 0, 
    duration: 0.8, 
    ease: 'power3.out',
    scrollTrigger: {
      trigger: '.section-element',
      start: 'top 85%',
      end: 'top 40%',
      scrub: false,
      once: true
    }
  }
);

// Staggered list
gsap.from('.list-item', {
  opacity: 0, y: 24,
  stagger: 0.08,
  duration: 0.6,
  ease: 'power2.out'
});

// Parallax hero
gsap.to('.hero-bg', {
  yPercent: -20,
  ease: 'none',
  scrollTrigger: {
    trigger: '.hero',
    start: 'top top',
    end: 'bottom top',
    scrub: true
  }
});
```

**Lenis smooth scroll**:
```javascript
const lenis = new Lenis({ lerp: 0.08, smoothWheel: true });
```

---

## 3D Web (Three.js / R3F)

**Reference aesthetic**: Spatial computing, premium product visualization, particle fields.

### Scene Setup
```javascript
// Dark scene, fog for depth
scene.background = new THREE.Color(0x0C0C10);
scene.fog = new THREE.FogExp2(0x0C0C10, 0.015);

// Subtle ambient + key light
const ambient = new THREE.AmbientLight(0x1a1a2e, 0.5);
const key = new THREE.DirectionalLight(0xffffff, 1.2);
key.position.set(5, 10, 5);

// Post-processing
// Bloom (subtle): threshold 0.9, strength 0.3, radius 0.5
// Vignette: darkness 0.5, offset 0.5
// Chromatic aberration: very subtle (0.002)
```

### Material Presets
```javascript
// Chrome (Stream A)
const chromeMaterial = new THREE.MeshStandardMaterial({
  color: 0xB2BFC9,
  metalness: 0.95,
  roughness: 0.05,
  envMapIntensity: 1.5
});

// Glass (Stream B)
const glassMaterial = new THREE.MeshPhysicalMaterial({
  transparent: true,
  opacity: 0.15,
  roughness: 0.05,
  metalness: 0,
  transmission: 0.9,
  thickness: 0.5,
  color: 0xffffff
});

// Dark matte (universal)
const darkMatte = new THREE.MeshStandardMaterial({
  color: 0x141418,
  metalness: 0.1,
  roughness: 0.8
});
```

### Performance Gate (must pass before delivery)
- FPS: 60fps on a mid-tier laptop (2021 MacBook Pro M1)
- Mobile: 30fps minimum on iPhone 13+
- First frame paint: under 3 seconds on good connection
- No texture above 2048×2048
- No single mesh above 100k triangles without LOD

---

## Awwwards Quality Bar

Every 3D web project must pass:

- [ ] Unique concept — not a clone of an existing site
- [ ] Performance: 60fps desktop, 30fps mobile
- [ ] Typography is precisely set (scale, tracking, weight)
- [ ] Transitions are smooth, intentional, and use custom easing
- [ ] Dark mode is the design, not an afterthought
- [ ] Every interaction has feedback
- [ ] Mobile experience is not broken (may be simplified, not broken)
- [ ] Load screen/animation is considered
- [ ] No Lorem Ipsum in delivery
- [ ] Glows, gradients, and particle fields are restrained and purposeful
