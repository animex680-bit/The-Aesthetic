# Documents — Rules
## Decks, PDFs, Proposals, Reports

---

## Stream Selection for Documents

Documents are Stream B dominated — precision, clarity, intelligence.
Stream A enters only in hero/cover moments.

**Default**: B 90% / A 10% (cover only)

---

## Pitch Deck Layout

Reference: Festina One Page Website Award — restraint, white space, extreme quality.

### Slide Dimensions
- Widescreen: 1920×1080 (16:9) — standard for screen presentations
- Print: A4 landscape (297×210mm) — if PDF export needed
- Square: 1440×1440 — LinkedIn / social sharing

### Slide Grid
- Margins: 80px all sides (desktop), 60px print
- Gutter: 24px between columns
- Max content columns: 2 (never 3 in a deck — too busy)

### Slide Types (use all, in rotation)
```
COVER:      Full bleed image (Stream A) + company name + tagline
SECTION:    Big number or single word, massive type, clean
CONTENT:    2-column: headline left, body/proof right
DATA:       Chart or stat, full-width, minimal chrome
QUOTE:      One sentence, oversized, attributed
IMAGE:      Full-bleed photograph or render, minimal text overlay
CLOSE/CTA:  Clean, dark, single message, contact info
```

---

## Typography for Decks

```
Cover headline:    Cormorant Garamond 72–96pt, light weight (Stream A moment)
Section headline:  Inter 64–96pt Bold, letter-spacing -0.03em
Slide title:       Inter 28–36pt SemiBold, letter-spacing -0.01em
Body:              Inter 16–20pt Regular, line-height 1.6
Caption/Source:    Inter 11pt, ALL CAPS, letter-spacing 0.1em, muted color
Number (stat):     Inter 64–120pt Bold, the visual anchor of the slide
```

---

## Color for Documents

**Light version** (more professional default for decks):
```
Background:   #FFFFFF or #F8F8FC (very slightly blue-tinted)
Surface:      #F2F2F8
Accent:       Use stream_b accent colors (#3B82F6 blue primary)
Text primary: #0C0C10
Text second:  #6E7F8D
Border:       #E2E2EE
```

**Dark version** (for premium/creative/brand contexts):
```
Background:   #0C0C10
Surface:      #141418
Accent:       Stream B accents
Text:         #F0F0F6, #9090A8
```

**Cover slide**: Always Stream A — dark background, editorial image or texture, serif or light-weight sans headline.

---

## Data Visualization

Data is part of the aesthetic. Charts must look deliberate.

**Chart colors** (always from the stream_b accent palette):
```
Primary series:   #3B82F6 (blue)
Secondary:        #0EA5E9 (teal)
Tertiary:         #8B5CF6 (purple)
Positive:         #10B981 (emerald)
Negative:         #F43F5E (rose)
Neutral:          #6E7F8D (muted)
```

**Chart rules**:
- No 3D charts (flat, clear, honest)
- No pie charts for more than 3 segments (use bar or donut instead)
- Grid lines: very light (#E2E2EE on light, #2A2A35 on dark)
- No chartjunk — no decorative elements that don't convey data
- Always label the key insight in text above the chart (don't make the reader decode)

---

## PDF / Report Styling

For longer documents (10+ pages):

**Structure**:
```
Cover:        Full page — Stream A visual, title, date, brand
Contents:     Text-only table of contents, clean numbers
Section breaks: Full page — big section number + section name, dark BG
Content pages: 2-column grid, headline → body → supporting media
Callout boxes:  Glass-style card with stream_b accent border
Pull quotes:  Oversized, left-border accent, italic (Cormorant)
Data pages:   Chart + annotation, full bleed capability
Back cover:   Contact, brand mark, url
```

**Spacing**:
- Section break after every major topic
- Minimum 24px between any two content elements
- Margin notes possible (64px right margin for annotations)

---

## Proposals

Proposals should feel like premium deliverables, not email attachments.

**What a proposal must communicate visually**:
1. We are premium — the design of the proposal proves the standard of the work
2. We are precise — the layout is intentional, nothing is approximate
3. We respect your time — information hierarchy is clear, not buried

**Proposal sections** (visual treatment):
```
Cover page:       Full-bleed dark, serif headline, Stream A energy
Executive summary:Clean white/light, large intro paragraph, no clutter
The Work:         Side-by-side: challenge | solution, clean grid
The Investment:   Numbers as heroes (big, centered), package tiers in cards
Next Steps:       Simple numbered list, large and clean
About:            Minimal bio, project references (quality > quantity)
```

---

## Quality Check for Documents

- [ ] Cover slide could stand alone as an art piece
- [ ] No slide has more than 40 words (except content slides — max 80)
- [ ] All charts clearly labeled with the key insight in a headline
- [ ] Typography follows the scale (no freelance sizing)
- [ ] Colors from the token file (no ad-hoc color choices)
- [ ] Light version checked at actual reading size (not design view)
- [ ] No Lorem Ipsum anywhere
- [ ] PDF export: check font embedding, image resolution minimum 150dpi
- [ ] The document conveys premium — would you be embarrassed handing this to a Fortune 500 client?
