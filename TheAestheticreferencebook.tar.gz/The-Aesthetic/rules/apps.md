# Apps — Rules
## Mobile, Web App, and UI Design

---

## Stream Selection

Apps are predominantly Stream B (THE INTERFACE). Stream A infuses emotional moments — onboarding, empty states, hero illustrations.

**Default**: Stream B 85% / Stream A 15%

---

## Design System Foundation

Every app must have a token-based design system before any component is built.
Use `/tokens/colors.json` (stream_b section) as the starting point.

**Non-negotiable starting conditions**:
1. Color tokens defined (not hardcoded values)
2. Typography scale defined (from `/tokens/typography.json`)
3. Spacing system defined (8px base unit)
4. Shadow/depth system defined (from `/tokens/shadows.json`)
5. Dark mode first — light mode added second if needed

---

## Component Hierarchy

### Surfaces (elevation layers)
```
Level 0: bg_void     #0C0C10  — Page background
Level 1: surface_l1  #141418  — Cards, panels
Level 2: surface_l2  #1E1E26  — Modal base, overlays
Level 3: surface_l3  #28282F  — Dropdowns, tooltips
Glass:   rgba(255,255,255,0.06) — Special glass panels
```

### Typography Roles
```
Display:   hero numbers, key stats (extra large, heavy)
Heading:   screen titles, section headers
Body:      regular readable content
Caption:   metadata, timestamps, footnotes
Label:     ALL CAPS 0.1em tracking — category, status, section ID
Mono:      numbers, code, data
```

### Interactive States
Every interactive element must have all 5 states:
```
Default  → Hover (+brightness or opacity change, 150ms)
         → Focus (ring: 2px outline, accent color)
         → Active/Press (scale 0.97, 100ms)
         → Disabled (opacity 0.4, cursor not-allowed)
```

---

## Dark Mode Implementation

**Do NOT** implement dark mode as:
- Just changing background to `#000000` — that is dead black, not designed
- Just inverting colors — it destroys hierarchy
- Just adding `filter: invert(1)` — unacceptable

**Correct dark mode approach**:
1. Background: `#0C0C10` (blue-tinted, not pure black)
2. Elevate surfaces with lighter values (not just opacity)
3. Shadows use transparency (not colored background)
4. Text: layered from `#F0F0F6` (primary) → `#9090A8` (secondary) → `#5C5C72` (muted)
5. Borders: very subtle `#2A2A35` to `#3A3A48`
6. Colors may be more saturated in dark mode (works better on dark)

---

## Glassmorphism in Apps (Reference: Liquid Glass UI Kit)

Use glass components for:
- Cards that hover over content (maps, media players)
- Navigation bars with content visible behind
- Modals on content-heavy backgrounds
- Special "premium" feature sections

```css
/* Standard glass component */
.glass {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 16px;
  backdrop-filter: blur(20px) saturate(1.8);
  -webkit-backdrop-filter: blur(20px) saturate(1.8);
}
/* Performance note: limit backdrop-filter elements to 3-5 per screen */
```

---

## Neumorphism in Apps (Reference: Virtual Assistant App)

Use neumorphic style for:
- Light mode interfaces (wellness, productivity, calm aesthetic)
- Settings panels, sliders, toggle elements
- Physical-world metaphors

**Exact spec from reference**:
```css
/* Background: #EFF2F9, Surface: #E4EBF1 */
.neuro-card {
  background: #E4EBF1;
  border-radius: 16px;
  box-shadow: -5px -5px 10px #FAFBFF,
               5px  5px 10px rgba(22, 27, 29, 0.23);
}
.neuro-card-large {
  box-shadow: -20px -20px 40px #FAFBFF,
               20px  20px 40px rgba(22, 27, 29, 0.23);
}
.neuro-pressed {
  box-shadow: inset -5px -5px 10px #FAFBFF,
              inset  5px  5px 10px rgba(22, 27, 29, 0.23);
}
```

**Font for neumorphic**: Campton Book / Campton Light (exact reference spec)

---

## Spatial Computing Reference (Vision Pro)

From reference: "Threads: Vision Pro. UI Design"

For spatial/VR/AR app contexts:
- Panels: floating glass at slight angle, depth-aware
- Typography: extra clean, high contrast (user at varied distance)
- No small text — minimum 24pt for spatial UI
- Interactions: gaze + gesture, not tap (different affordances)
- Background: show depth via blur falloff, not flat color
- Color: slightly muted (avoid eye fatigue in mixed reality)

---

## Micro-interaction Standards

```javascript
// Button press
{ scale: 0.97, duration: 0.1, ease: 'power2.out' }
// followed by:
{ scale: 1.0,  duration: 0.15, ease: 'power2.inOut' }

// Toggle switch
{ duration: 0.2, ease: 'power2.out' }  // thumb slides
{ duration: 0.15 }                      // background color change

// Card elevation (hover)
{ y: -4, boxShadow: 'deeper', duration: 0.2, ease: 'power2.out' }

// Modal open
{ opacity: 0→1, scale: 0.96→1.0, duration: 0.3, ease: 'cubic-bezier(0.32, 0.72, 0, 1)' }

// Drawer slide
{ x: '100%'→'0%', duration: 0.35, ease: 'cubic-bezier(0.32, 0.72, 0, 1)' }
```

---

## Emotional UI Moments (Stream A infusion)

**Where Stream A comes in for apps**:

1. **Onboarding hero screens**: Full dark backgrounds, editorial photography or sculptural illustration, large Cormorant serif tagline, slow fade-in
2. **Empty states**: Instead of generic "no content" icons, use minimal editorial photography or abstract art — make the user feel something
3. **Achievement moments**: Particle burst + slow drift, not confetti (unless playful brand)
4. **Premium feature reveal**: Glass surface lifts, slow reveal, dramatic type
5. **Error states**: Deep crimson, not baby red. Cold, precise, not panicked.

---

## Observatory App Reference (Emotional AI UI)

From reference "8796161770502459.jpg":
- Dark mode, card-based layout
- "Reality Checks", "Offline Journal", "Your Aura", "You're a badass!" — emotional, direct copy
- Gradient accent pills for categories
- Large rounded corners (24px) for softness in an otherwise dark UI
- Lesson: emotional AI apps can be dark AND warm. Use warm accent colors (rose, amber) within dark surfaces.

---

## Quality Check

- [ ] Color tokens used (no hardcoded values in components)
- [ ] All 5 interactive states implemented
- [ ] Dark mode is designed (not just inverted)
- [ ] Typography follows scale from `/tokens/typography.json`
- [ ] Tap targets: minimum 44×44px (iOS) or 48×48dp (Android)
- [ ] Backdrop-filter elements ≤ 5 per screen (performance)
- [ ] Loading states designed (skeleton screens preferred over spinners)
- [ ] Error states designed (not just default browser alerts)
- [ ] No layout shift during data load
